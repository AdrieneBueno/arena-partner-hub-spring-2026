Arena Spring 2026 — Ready-to-post invitations

Three generic Arena invitation graphics, post-as-is:
  - 10-invitation-square.png   (1080x1080 — IG/LinkedIn feed)
  - 11-invitation-portrait.png (1080x1350 — IG/LinkedIn portrait)
  - 12-invitation-story.png    (1080x1920 — Story/Reel)

For branded x@ARENA templates with logo space and [COMMUNITY NAME] templates,
edit in Canva: https://canva.link/hdjc8bqoudtr4yc

Questions: Adriene Bueno - adriene@arenatalent.com - 408-401-4533
